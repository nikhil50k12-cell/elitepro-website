const $ = s => document.querySelector(s);
const money = p => '₹' + (Number(p || 0) / 100).toFixed(2);
async function api(url, options={}) {
  const res = await fetch(url, {headers:{'Content-Type':'application/json'}, credentials:'same-origin', ...options});
  const data = await res.json().catch(()=>({error:'Unexpected server response.'}));
  if (!res.ok) throw new Error(data.error || 'Request failed.');
  return data;
}
function message(el, text, bad=false){el.textContent=text;el.style.color=bad?'#c62828':'#218454'}
async function refresh(){
  const me = await api('/api/me');
  $('#balance').textContent=money(me.balancePaise);
  $('#profileText').textContent='Username: '+me.username;
  $('#auth').classList.add('hidden');$('#app').classList.remove('hidden');$('#logout').classList.remove('hidden');
  const tasks=await api('/api/tasks');
  $('#taskList').innerHTML='';
  tasks.forEach(t=>{
    const div=document.createElement('div');div.className='task';
    const title=document.createElement('h3');title.textContent=t.title;
    const desc=document.createElement('p');desc.textContent=t.description+' Reward: '+money(t.rewardPaise);
    const status=document.createElement('p');status.className='muted';status.textContent=t.submissionStatus?('Status: '+t.submissionStatus):'Not submitted';
    div.append(title,desc,status);
    if(!t.submissionStatus){
      const form=document.createElement('form');const input=document.createElement('input');input.name='proof';input.placeholder='Proof / reference (do not enter passwords or OTPs)';input.required=true;
      const btn=document.createElement('button');btn.textContent='Submit for review';form.append(input,btn);
      form.onsubmit=async e=>{e.preventDefault();try{const r=await api('/api/tasks/'+t.id+'/submit',{method:'POST',body:JSON.stringify({proof:input.value})});message(status,r.message);form.remove()}catch(err){message(status,err.message,true)}};
      div.append(form);
    }
    $('#taskList').append(div);
  });
}
$('#authForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{await api('/api/login',{method:'POST',body:JSON.stringify(Object.fromEntries(f))});await refresh()}catch(err){message($('#authMsg'),err.message,true)}};
$('#signup').onclick=async()=>{const f=new FormData($('#authForm'));try{await api('/api/signup',{method:'POST',body:JSON.stringify(Object.fromEntries(f))});await refresh()}catch(err){message($('#authMsg'),err.message,true)}};
$('#logout').onclick=async()=>{await api('/api/logout',{method:'POST'});location.reload()};
$('#withdrawForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{const r=await api('/api/withdraw',{method:'POST',body:JSON.stringify(Object.fromEntries(f))});message($('#withdrawMsg'),r.message);await refresh()}catch(err){message($('#withdrawMsg'),err.message,true)}};
async function history(){try{const h=await api('/api/history');$('#historyList').innerHTML='';[...h.ledger.map(x=>({...x,type:'Ledger'})),...h.withdrawals.map(x=>({...x,type:'Withdrawal'}))].forEach(x=>{const d=document.createElement('div');d.className='entry';d.textContent=`${x.type} • ${x.note||x.status} • ${x.amountPaise!==undefined?money(x.amountPaise):''} • ${x.createdAt}`;$('#historyList').append(d)});if(!$('#historyList').children.length)$('#historyList').textContent='No history yet.'}catch(err){$('#historyList').textContent=err.message}}
$('#refreshHistory').onclick=history;
refresh().catch(()=>{});
